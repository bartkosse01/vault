var codeContainer = document.getElementById("code-Container");
var clickCounter = 0;
var numberOne;
var numberTwo;
var numberThree;
var numberButtons = document.getElementsByClassName('buttonNumber');
var greenBlock = document.getElementById("greenBlock");
var redBlock = document.getElementById("redBlock");
var intervalTimer = 0;
var myWinningSound;

function getNumber(clickedButton) {

    clickCounter++;

    codeContainer.innerHTML += clickedButton.value;

    if(clickCounter == 1){
        numberOne = clickedButton.value;
    }
    else if(clickCounter == 2){
        numberTwo = clickedButton.value;
    }
    else {
        numberThree = clickedButton.value
        disableButtons();
    }

    if (clickCounter == 3)
    {
        if(numberOne == 1 && numberTwo == 2 && numberThree == 3)
        {
            clickCounter = 0;
            var blink = setInterval(function() {
        
                //add +1 every time the setinterval function runs		
                intervalTimer++;
                
                goodanswerpopup();

                //method to show div on and off
                //change the css of the green and red box to create a blinking effect
                if (greenBlock.style.visibility == 'hidden') 
                {
                    greenBlock.style.visibility = 'visible';
                }
                else 
                {
                    greenBlock.style.visibility = 'hidden';
                }
            
                //check if the interval has runned ten times
                if(intervalTimer == 10) {
            
                    //ClearInterval function stops the interval after 10 times
                    clearInterval(blink);
                    enableButtons();
                    //codeContainer.innerHTML = "";
                }
            
            }, 500);

        }
        else
        {
            clickCounter = 0;
            var blink = setInterval(function() {
        
                //add +1 every time the setinterval function runs		
                intervalTimer++;

                wronganswerpopup();
            
                //method to show div on and off
                //change the css of the green and red box to create a blinking effect
                if (redBlock.style.visibility == 'hidden') 
                {
                    redBlock.style.visibility = 'visible';
                }
                else 
                {
                    redBlock.style.visibility = 'hidden';
                }
            
                //check if the interval has runned ten times
                if(intervalTimer == 10) {
                    //ClearInterval function stops the interval after 10 times
                    clearInterval(blink);
                    enableButtons();
                }
            }, 500);
        }
    }

    console.log(numberOne);
    console.log(numberTwo);
    console.log(numberThree);

}

function disableButtons() {

	//used to loop through all buttons and disable them with attribute disable
	//so that it isn't possible to click more then three times
	for(i=0; i < numberButtons.length; i++) {
		numberButtons[i].setAttribute('disabled', 'disabled');
	}
}

function enableButtons() {
	//used to loop through all buttons and enable them again, remove attribute disabled
	for(i=0; i < numberButtons.length; i++) {
		numberButtons[i].removeAttribute('disabled');
	}
}

function goodanswerpopup() {
    alert("the wright code is pressed")
}

function wronganswerpopup() {
    alert("the wrong code is pressed")
}